SELECT * FROM bookings WHERE event_date = "2030-05-22" AND buyer_id = "ABC123456789"
