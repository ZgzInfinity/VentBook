<?php

namespace App\Tests\Integration\Service;

use PHPUnit\Framework\TestCase;
use App\Service\Calculadora;

class CalculadoraTest extends TestCase
{
   public function testSumar(): void
   {
       $calculadora = new Calculadora();
       $result = $calculadora->sumar(2, 3);
       $this->assertEquals(5, $result, 'El método debería sumar correctamente dos números');
   }
}