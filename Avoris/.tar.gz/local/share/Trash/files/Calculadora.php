<?php

namespace App\Service;

class Calculadora 
{ 
	public function sumar(int $a, int $b): int 
	{
		return $a + $b;
	} 
}